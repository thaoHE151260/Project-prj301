package Dal;

/**
 *
 * @author HuuTrinh
 */
public class BillDetailDAO extends DBContext{
    
}
