package Dal;

/**
 *
 * @author HuuTrinh
 */
public class BillDAO extends DBContext{
    
}
