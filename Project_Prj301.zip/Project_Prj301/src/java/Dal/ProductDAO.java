package Dal;

/**
 *
 * @author DELL i7
 */
public class ProductDAO extends DBContext{
    
}
