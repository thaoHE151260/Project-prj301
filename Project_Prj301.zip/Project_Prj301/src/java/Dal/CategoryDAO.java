package Dal;

/**
 *
 * @author HuuTrinh
 */
public class CategoryDAO extends DBContext{
    
}
